from __future__ import with_statement
import cgi
from google.appengine.api import users
import webapp2
import csv
import os
import string
import io
import StringIO

import jinja2


jinja_environment = jinja2.Environment(autoescape=True,
    loader=jinja2.FileSystemLoader(os.path.join(os.path.dirname(__file__), 'templates')))

class MainPage(webapp2.RequestHandler):
    
    def get(self):
        
        template_values = {
            'name': ''
        }

        template = jinja_environment.get_template('index.html')
        self.response.write(template.render(template_values))
        
#class for modify a csv file in according to the specific defined in the
#textarea in index.html
class Discretization(webapp2.RequestHandler):

    
    #post ot the form in index.html
    def post(self):
        
        #text in the textarea
        #splitted for lines
        expressions=self.request.get('expressions').splitlines()    
        
        #the csv file is returned as a string
        read=self.request.get('file')
        
        #return a list of dictionary when every line is a tuple pf the csv file
        #; is the delimiter
        stringReader = csv.DictReader(StringIO.StringIO(read),delimiter=";")
        
        #is necessary becouse the keys in stringReader are not ordered
        #see csv documentation python
        stringReader2 = csv.reader(StringIO.StringIO(read), delimiter=";")
        
        
        #take the first row ot the columns name
        for row in stringReader2:
            keys=row
            break
        
        #print keys
        
        
        #list modified
        listRow=[]        
        
       
        for row in stringReader:
            self.myreplace(row,expressions)
            listRow.append(row)
            
            
        #response header is an application/csv 
        self.response.headers['Content-Type'] = 'application/csv'
        
        
        writer = csv.DictWriter(self.response.out,keys,delimiter=";")

        writer.writeheader()
        writer.writerows(listRow)
    
    #function for replace the discrete value with the intervalls
    #for every row of the database and all the expressions in the textarea
    def myreplace(self,row,expressions):
        
        
        for expression in expressions:
            #value[0] is the columns name
            value=expression.split()
            
            #1 becouse the first is the column name
            for i in range(1,len(value)):
                
                if "-" in value[i]:
                    substring=value[i].split("-")
                    #numbers before and after the -
                    inferior=float(substring[0])
                    superior=float(substring[1])
                    
                    #value in the csv file
                    myvalue=row[value[0]]
                    
                    if "?" in myvalue:
                        break
                    
                    
                    myvalueInt=float(myvalue)
                    
                    #if is in the interval replace the value with the interval
                    if( (myvalueInt >= inferior) and (myvalueInt < superior)):
                        row[value[0]]=value[i]
                        break
                
                if "<" in value[i]:
                    
                    substring=value[i][1:len(value[i])]
                    
                    myvalue=row[value[0]]
                    
                    if "?" in myvalue:
                        break
                    
                    if(float(myvalue)<float(substring)):
                        row[value[0]]=value[i]
                        break
                        
                if ">" in value[i]:
                    
                    substring=value[i][1:len(value[i])]
                    
                    myvalue=row[value[0]]
                    
                    if "?" in myvalue:
                        break
                    
                    if(float(myvalue)>float(substring)):
                        row[value[0]]=value[i]
                        break
        
        

application = webapp2.WSGIApplication([
    ('/', MainPage),
    ('/process.csv', Discretization),
], debug=True)